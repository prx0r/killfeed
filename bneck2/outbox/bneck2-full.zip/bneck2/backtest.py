"""bneck2 backtest — leakage-safe walk-forward, stdlib port of the vendored
postagi_kernel/backtest.py (which needs numpy/pandas).

Same protocol (Agentic-Trading-survey response): score knowable at `date`,
forward_return realized after; per-date rebalance; turnover-charged costs;
no same-period look-ahead. Rows are plain dicts:
  {date, ticker, score, forward_return}
"""
from __future__ import annotations

import math


def make_positions(scores: dict[str, float], quantile: float = 0.2,
                   gross: float = 1.0) -> dict[str, float]:
    if not 0 < quantile < 0.5:
        raise ValueError("quantile must be in (0,.5)")
    order = sorted(scores, key=lambda t: scores[t])
    n = max(1, int(len(order) * quantile))
    pos = {t: 0.0 for t in order}
    for t in order[:n]:
        pos[t] = -gross / (2 * n)
    for t in order[-n:]:
        pos[t] = gross / (2 * n)
    return pos


def walk_forward(panel: list[dict], cost_bps: float = 10.0,
                 quantile: float = 0.2) -> tuple[list[dict], dict]:
    dates: dict[str, list[dict]] = {}
    for r in panel:
        dates.setdefault(str(r["date"]), []).append(r)
    prev: dict[str, float] = {}
    rows = []
    for date in sorted(dates):
        g = dates[date]
        pos = make_positions({r["ticker"]: float(r["score"]) for r in g},
                             quantile)
        ret = {r["ticker"]: float(r["forward_return"]) for r in g}
        tickers = set(pos) | set(prev)
        turnover = sum(abs(pos.get(t, 0.0) - prev.get(t, 0.0))
                       for t in tickers)
        gross = sum(pos[t] * ret.get(t, 0.0) for t in pos)
        cost = turnover * cost_bps / 10000
        rows.append({"date": date, "gross_return": round(gross, 6),
                     "turnover": round(turnover, 6), "cost": round(cost, 6),
                     "net_return": round(gross - cost, 6)})
        prev = pos
    nets = [r["net_return"] for r in rows]
    n = len(nets)
    ann = ((math.prod(1 + x for x in nets)) ** (12.0 / max(n, 1)) - 1) if n else 0.0
    mean = sum(nets) / n if n else 0.0
    var = sum((x - mean) ** 2 for x in nets) / (n - 1) if n > 1 else 0.0
    vol = math.sqrt(var) * math.sqrt(12.0) if n > 1 else 0.0
    cum, peak, max_dd = 1.0, 1.0, 0.0
    for x in nets:
        cum *= 1 + x
        peak = max(peak, cum)
        max_dd = min(max_dd, cum / peak - 1)
    return rows, {"annualized_return": round(ann, 6),
                  "annualized_vol": round(vol, 6),
                  "sharpe": round(ann / vol, 4) if vol > 0 else 0.0,
                  "max_drawdown": round(max_dd, 6), "periods": n,
                  "cost_bps": cost_bps}
